package br.senai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FuncionariooApplication {

	public static void main(String[] args) {
		SpringApplication.run(FuncionariooApplication.class, args);
	}

}
